
import pygame  # 引入 pygame 模組/ Import pygame module
import time  # 引入 time 模組/ Import time module
import random  # 引入 random 模組/ Import random module
import os  # 引入 os 模組/ Import os module
from pygame.sprite import Sprite  # 從 pygame.sprite 中引入 Sprite 類別/ Import Sprite class from pygame.sprite

# Game constants  # 遊戲常數/ Game constants
SCREEN_WIDTH = 800  # 定義螢幕寬度/ Define screen width
SCREEN_HEIGHT = 500  # 定義螢幕高度/ Define screen height
BG_COLOR = pygame.Color(0, 0, 0)  # 定義背景顏色為黑色/ Define background color as black
TEXT_COLOR = pygame.Color(255, 0, 0)  # 定義文字顏色為紅色/ Define text color as red
BUTTON_COLOR = (100, 100, 100)  # 定義按鈕顏色/ Define button color
HOVER_COLOR = (150, 150, 150)  # 定義滑鼠懸停時按鈕顏色/ Define hover button color

# Initialize pygame  # 初始化 pygame/ Initialize pygame
pygame.init()  # 呼叫 pygame 初始化/ Call pygame initialization
pygame.mixer.init()  # 初始化 pygame 音效混音器/ Initialize pygame mixer

# Load images with error handling  # 載入圖片並處理錯誤/ Load images with error handling
def load_image(path, scale=None):  # 定義 load_image 函式/ Define load_image function
    try:  # 嘗試執行以下程式碼/ Try to execute the following code
        img = pygame.image.load(path)  # 使用 pygame 載入圖片/ Load image using pygame
        if scale:  # 如果需要縮放圖片/ If scaling is required
            img = pygame.transform.scale(img, scale)  # 轉換圖片尺寸/ Scale the image
        return img  # 返回圖片/ Return the image
    except Exception as e:  # 如果發生錯誤/ In case of error
        print(f"Error loading image {path}: {e}")  # 輸出錯誤訊息/ Print error message
        surf = pygame.Surface((50, 50) if not scale else scale)  # 創建預設表面/ Create default surface
        surf.fill((255, 0, 255))  # 填充洋紅色作為錯誤顯示/ Fill with magenta as error color
        return surf  # 返回錯誤表面/ Return the error surface

# Load game assets  # 載入遊戲資源/ Load game assets
BG_IMAGE = load_image('img/BG.jpg', (SCREEN_WIDTH, SCREEN_HEIGHT))  # 載入背景圖片/ Load background image
MENU_BG_IMAGE = load_image('img/menuBG.jpg', (SCREEN_WIDTH, SCREEN_HEIGHT))  # 載入選單背景圖片/ Load menu background image

# Game states  # 遊戲狀態/ Game states
MENU = 0  # 定義選單狀態/ Define menu state
PLAYING = 1  # 定義遊戲進行中狀態/ Define playing state
GAME_OVER = 2  # 定義遊戲結束狀態/ Define game over state
VICTORY = 3  # 定義勝利狀態/ Define victory state

# Font setup  # 字體設置/ Font setup
try:  # 嘗試執行以下程式碼/ Try to execute the following code
    font_path = 'font.ttf' if os.path.exists('font.ttf') else None  # 使用 font.ttf 作為字體/ Use font.ttf as the font
    default_font = pygame.font.Font(font_path, 30) if font_path else pygame.font.SysFont(None, 30)  # 設置預設字體/ Set default font
except:  # 如果發生錯誤/ In case of error
    default_font = pygame.font.SysFont(None, 30)  # 使用系統字體/ Use system font

class BaseItem(Sprite):  # 定義 BaseItem 類別，繼承自 Sprite/ Define BaseItem class inheriting from Sprite
    def __init__(self, color, width, height):  # 初始化 BaseItem/ Initialize BaseItem
        super().__init__()  # 呼叫父類別初始化/ Call superclass initializer

class Button:  # 定義 Button 類別/ Define Button class
    def __init__(self, text, x, y, width, height, action=None):  # 初始化按鈕/ Initialize button
        self.rect = pygame.Rect(x, y, width, height)  # 定義按鈕矩形區域/ Define button rectangle area
        self.text = text  # 設定按鈕文字/ Set button text
        self.action = action  # 設定按鈕動作/ Set button action
        self.hovered = False  # 初始化懸停狀態/ Initialize hovered state

    def draw(self, surface):  # 定義畫按鈕的方法/ Define method to draw the button
        color = HOVER_COLOR if self.hovered else BUTTON_COLOR  # 根據懸停狀態選擇顏色/ Choose color based on hovered state
        pygame.draw.rect(surface, color, self.rect, border_radius=5)  # 畫出按鈕矩形/ Draw the button rectangle
        
        # 動態調整文字大小以適應按鈕框  # 根據按鈕大小動態調整文字大小/ Dynamically adjust text size to fit button
        font_size = 30  # 初始字體大小/ Initial font size
        while True:  # 持續嘗試直到文字合適/ Loop until the text fits
            font = self.get_font(font_size)  # 獲取指定大小字體/ Get font with specified size
            text_surf = font.render(self.text, True, (255, 255, 255))  # 渲染按鈕文字/ Render button text
            if text_surf.get_width() <= self.rect.width - 10 or font_size <= 10:  # 如果文字寬度適合按鈕或達到最小字體/ If text fits or minimum font size reached
                break  # 結束調整/ Break the loop
            font_size -= 1  # 減小字體大小/ Decrease font size
        
        text_rect = text_surf.get_rect(center=self.rect.center)  # 取得文字矩形並置中/ Get text rectangle and center it
        surface.blit(text_surf, text_rect)  # 將文字繪製到表面/ Blit the text onto the surface

    @staticmethod
    def get_font(size):  # 定義靜態方法以獲取字體/ Define static method to get font
        try:  # 嘗試以下操作/ Try the following
            return pygame.font.Font(font_path, size) if font_path else pygame.font.SysFont(None, size)  # 返回字體/ Return the font
        except:  # 如果發生錯誤/ In case of error
            return pygame.font.SysFont(None, size)  # 返回系統字體/ Return system font

class MainGame:  # 定義 MainGame 類別/ Define MainGame class
    def __init__(self):  # 初始化 MainGame/ Initialize MainGame
        self.window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))  # 創建遊戲視窗/ Create game window
        pygame.display.set_caption('Tank Battle')  # 設置視窗標題/ Set window caption
        self.clock = pygame.time.Clock()  # 創建時鐘物件/ Create clock object
        self.game_state = MENU  # 初始化遊戲狀態為選單/ Initialize game state as MENU
        self.score = 0  # 初始化分數/ Initialize score
        self.enemy_count = 5  # 設定敵人數量/ Set enemy count
        self.buttons = []  # 初始化按鈕列表/ Initialize button list
        self.result_text = ""  # 初始化結果文字/ Initialize result text
        self.menu_bg = MENU_BG_IMAGE  # 設定選單背景/ Set menu background
        self.my_tank = None  # 初始化玩家坦克/ Initialize player tank
        self.enemyTankList = []  # 初始化敵人坦克列表/ Initialize enemy tank list
        self.myBulletList = []  # 初始化玩家子彈列表/ Initialize player bullet list
        self.enemyBulletList = []  # 初始化敵人子彈列表/ Initialize enemy bullet list
        self.explodeList = []  # 初始化爆炸列表/ Initialize explosion list
        self.WallList = []  # 初始化牆壁列表/ Initialize wall list

    def generate_random_position(self, existing_objects, min_distance=50):  # 定義生成隨機位置的方法/ Define method to generate random position
        """Generate random position that doesn't overlap with existing objects"""  # 生成不與現有物件重疊的隨機位置/ Generate a random position that doesn't overlap with existing objects
        while True:  # 無限迴圈直到找到合適位置/ Loop indefinitely until a valid position is found
            x = random.randint(50, SCREEN_WIDTH - 50)  # 隨機生成 x 座標/ Generate a random x coordinate
            y = random.randint(50, SCREEN_HEIGHT - 50)  # 隨機生成 y 座標/ Generate a random y coordinate
            new_rect = pygame.Rect(x-25, y-25, 50, 50)  # 創建一個新的矩形區域/ Create a new rectangle area
            
            collision = False  # 初始化碰撞標誌為 False/ Initialize collision flag as False
            for obj in existing_objects:  # 檢查所有已存在的物件/ Check all existing objects
                if hasattr(obj, 'rect') and new_rect.colliderect(obj.rect):  # 如果有碰撞/ If there is a collision
                    collision = True  # 設置碰撞標誌為 True/ Set collision flag to True
                    break  # 離開迴圈/ Break the loop
                distance = ((new_rect.centerx - obj.rect.centerx)**2 +  # 計算中心點距離/ Calculate distance between centers
                        (new_rect.centery - obj.rect.centery)**2)**0.5  # 計算中心點距離/ Calculate distance between centers
                if distance < min_distance:  # 如果距離小於最小距離/ If distance is less than minimum distance
                    collision = True  # 設置碰撞標誌為 True/ Set collision flag to True
                    break  # 離開迴圈/ Break the loop
            
            if not collision:  # 如果沒有碰撞/ If there is no collision
                return (x, y)  # 返回生成的位置/ Return the generated position

    def generate_random_map(self):  # 定義生成隨機地圖的方法/ Define method to generate a random map
        """Generate random map with walls"""  # 生成包含牆壁的隨機地圖/ Generate a random map with walls
        self.WallList = []  # 清空牆壁列表/ Reset wall list
        existing_objects = []  # 初始化已存在物件列表/ Initialize existing objects list
        
        for _ in range(random.randint(10, 15)):  # 隨機生成 10 到 15 個牆壁/ Generate between 10 to 15 walls randomly
            pos = self.generate_random_position(existing_objects)  # 獲取不重疊的位置/ Get a non-overlapping position
            wall = Wall(pos[0], pos[1], self)  # 創建牆壁物件/ Create a wall object
            self.WallList.append(wall)  # 將牆壁加入列表/ Append wall to list
            existing_objects.append(wall)  # 將牆壁加入已存在物件列表/ Append wall to existing objects list
        
        return existing_objects  # 返回所有已存在的物件/ Return the list of existing objects

    def startGame(self):  # 定義開始遊戲的方法/ Define method to start the game
        self.game_loop()  # 呼叫遊戲主循環/ Call the game loop

    def game_loop(self):  # 定義遊戲主循環/ Define game loop
        running = True  # 初始化運行標誌為 True/ Set running flag to True
        while running:  # 當遊戲在運行中/ While the game is running
            self.clock.tick(60)  # 控制遊戲循環速度為 60 FPS/ Control game loop speed to 60 FPS
            
            if self.game_state == MENU:  # 如果遊戲狀態為選單/ If game state is MENU
                self.show_main_menu()  # 顯示主選單/ Show main menu
            elif self.game_state == PLAYING:  # 如果遊戲狀態為進行中/ If game state is PLAYING
                self.play_game()  # 執行遊戲/ Play the game
            elif self.game_state in (GAME_OVER, VICTORY):  # 如果遊戲狀態為結束或勝利/ If game state is GAME_OVER or VICTORY
                self.show_result_screen()  # 顯示結果畫面/ Show result screen
            
            for event in pygame.event.get():  # 處理事件/ Process events
                if event.type == pygame.QUIT:  # 如果事件是退出/ If the event is quit
                    running = False  # 設置運行標誌為 False/ Set running flag to False
            
            pygame.display.update()  # 更新螢幕/ Update display
        
        pygame.quit()  # 退出 pygame/ Quit pygame

    def show_main_menu(self):  # 定義顯示主選單的方法/ Define method to show main menu
        button_width, button_height = 200, 50  # 設置按鈕寬度和高度/ Set button width and height
        x_pos = (SCREEN_WIDTH - button_width) // 2  # 計算按鈕 x 座標/ Calculate button x position
        y_pos_start = (SCREEN_HEIGHT // 2) - button_height - 10  # 計算開始按鈕 y 座標/ Calculate start button y position
        y_pos_exit = (SCREEN_HEIGHT // 2) + 10  # 計算退出按鈕 y 座標/ Calculate exit button y position

        self.buttons = [  # 初始化按鈕列表/ Initialize button list
            Button("Start Game", x_pos, y_pos_start, button_width, button_height, self.start_new_game),  # 添加開始遊戲按鈕/ Add start game button
            Button("Exit Game", x_pos, y_pos_exit, button_width, button_height, self.endGame)  # 添加退出遊戲按鈕/ Add exit game button
        ]
        
        while self.game_state == MENU:  # 當遊戲狀態為選單時進入循環/ Loop while game state is MENU
            self.window.blit(self.menu_bg, (0, 0))  # 畫出選單背景/ Draw menu background
            
            # Semi-transparent overlay  # 半透明覆蓋/ Semi-transparent overlay
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)  # 創建半透明表面/ Create a semi-transparent surface
            overlay.fill((0, 0, 0, 128))  # 填充半透明黑色/ Fill with semi-transparent black
            self.window.blit(overlay, (0, 0))  # 畫出覆蓋/ Blit the overlay
            
            # Title  # 標題/ Title
            title_font = Button.get_font(50)  # 獲取大字體/ Get large font
            title_text = title_font.render("Tank Battle", True, (255, 0, 0))  # 渲染標題文字/ Render title text
            title_rect = title_text.get_rect(center=(SCREEN_WIDTH//2, 100))  # 置中標題/ Center the title
            self.window.blit(title_text, title_rect)  # 畫出標題/ Draw the title
            
            self.handle_menu_events()  # 處理選單事件/ Handle menu events
            
            for btn in self.buttons:  # 迭代所有按鈕/ Iterate through all buttons
                btn.draw(self.window)  # 畫出每個按鈕/ Draw each button
            
            pygame.display.flip()  # 更新畫面/ Update the display
            self.clock.tick(60)  # 控制更新速率/ Control the update rate

    def handle_menu_events(self):  # 定義處理選單事件的方法/ Define method to handle menu events
        for event in pygame.event.get():  # 取得所有事件/ Get all events
            if event.type == pygame.QUIT:  # 如果事件為退出/ If the event is quit
                self.endGame()  # 結束遊戲/ End the game
            if event.type == pygame.MOUSEBUTTONDOWN:  # 如果滑鼠按下/ If mouse button is pressed
                pos = pygame.mouse.get_pos()  # 取得滑鼠座標/ Get mouse position
                for btn in self.buttons:  # 檢查所有按鈕/ Check all buttons
                    if btn.rect.collidepoint(pos) and btn.action:  # 如果滑鼠點擊在按鈕上/ If mouse click is on a button
                        btn.action()  # 執行按鈕動作/ Execute button action
            if event.type == pygame.MOUSEMOTION:  # 如果滑鼠移動/ If mouse is moved
                pos = pygame.mouse.get_pos()  # 取得滑鼠座標/ Get mouse position
                for btn in self.buttons:  # 檢查所有按鈕/ Check all buttons
                    btn.hovered = btn.rect.collidepoint(pos)  # 設定懸停狀態/ Set hovered state

    def show_result_screen(self):  # 定義顯示結果畫面的方法/ Define method to show result screen
        button_width, button_height = 150, 50  # 設定按鈕寬高/ Set button width and height
        margin = 20  # 設定間距/ Set margin
        left_x = (SCREEN_WIDTH//2) - button_width - margin  # 計算左側按鈕 x 座標/ Calculate left button x position
        right_x = (SCREEN_WIDTH//2) + margin  # 計算右側按鈕 x 座標/ Calculate right button x position
        y_pos = (SCREEN_HEIGHT//2) + 50  # 計算按鈕 y 座標/ Calculate button y position

        self.buttons = [  # 初始化結果畫面按鈕/ Initialize result screen buttons
            Button("Restart", left_x, y_pos, button_width, button_height, self.start_new_game),  # 添加重新開始按鈕/ Add restart button
            Button("Main Menu", right_x, y_pos, button_width, button_height, lambda: setattr(self, 'game_state', MENU))  # 添加回主選單按鈕/ Add main menu button
        ]
        
        while self.game_state in (GAME_OVER, VICTORY):  # 當狀態為遊戲結束或勝利時/ While game state is GAME_OVER or VICTORY
            self.window.fill(BG_COLOR)  # 填充背景顏色/ Fill the background color
            
            result_font = Button.get_font(40)  # 獲取結果字體/ Get result font
            score_font = Button.get_font(30)  # 獲取分數字體/ Get score font
            result_text = result_font.render(self.result_text, True, (255, 0, 0))  # 渲染結果文字/ Render result text
            score_text = score_font.render(f"Score: {self.score}", True, (255, 255, 255))  # 渲染分數文字/ Render score text
            
            result_rect = result_text.get_rect(center=(SCREEN_WIDTH//2, 150))  # 設置結果文字位置/ Set result text position
            score_rect = score_text.get_rect(center=(SCREEN_WIDTH//2, 220))  # 設置分數文字位置/ Set score text position
            
            self.window.blit(result_text, result_rect)  # 畫出結果文字/ Blit result text
            self.window.blit(score_text, score_rect)  # 畫出分數文字/ Blit score text
            
            self.handle_menu_events()  # 處理事件/ Handle events
            
            for btn in self.buttons:  # 迭代所有按鈕/ Iterate through all buttons
                btn.draw(self.window)  # 畫出每個按鈕/ Draw each button
            
            pygame.display.flip()  # 更新畫面/ Update the display
            self.clock.tick(60)  # 控制更新速率/ Control the update rate

    def start_new_game(self):  # 定義開始新遊戲的方法/ Define method to start a new game
        self.game_state = PLAYING  # 將遊戲狀態設定為進行中/ Set game state to PLAYING
        self.score = 0  # 重置分數/ Reset score
        self.initialize_game_objects()  # 初始化遊戲物件/ Initialize game objects
        Music('img/start.wav').play()  # 播放開始音效/ Play start sound

    def initialize_game_objects(self):  # 定義初始化遊戲物件的方法/ Define method to initialize game objects
        existing_objects = self.generate_random_map()  # 生成隨機地圖並獲得現有物件/ Generate random map and get existing objects
        
        # Player tank  # 玩家坦克/ Player tank
        player_pos = self.generate_random_position(existing_objects, 100)  # 獲取玩家坦克隨機位置/ Get random position for player tank
        self.my_tank = MyTank(player_pos[0], player_pos[1], self)  # 創建玩家坦克/ Create player tank
        existing_objects.append(self.my_tank)  # 將玩家坦克加入現有物件列表/ Append player tank to existing objects
        
        # Enemy tanks  # 敵人坦克/ Enemy tanks
        self.enemyTankList = []  # 初始化敵人坦克列表/ Initialize enemy tank list
        for _ in range(self.enemy_count):  # 為每個敵人生成位置/ For each enemy tank, generate a position
            enemy_pos = self.generate_random_position(existing_objects, 100)  # 獲取敵人坦克隨機位置/ Get random position for enemy tank
            enemy = EnemyTank(enemy_pos[0], enemy_pos[1], random.randint(1, 4), self)  # 創建敵人坦克/ Create enemy tank with random speed
            self.enemyTankList.append(enemy)  # 添加敵人坦克到列表/ Append enemy tank to list
            existing_objects.append(enemy)  # 添加敵人坦克到現有物件/ Append enemy tank to existing objects
        
        self.myBulletList = []  # 重置玩家子彈列表/ Reset player bullet list
        self.enemyBulletList = []  # 重置敵人子彈列表/ Reset enemy bullet list
        self.explodeList = []  # 重置爆炸列表/ Reset explosion list

    def play_game(self):  # 定義遊戲進行中的方法/ Define method for playing the game
        self.window.blit(BG_IMAGE, (0, 0))  # 畫出背景圖片/ Blit background image
        
        # Gameplay overlay  # 遊戲中覆蓋/ Gameplay overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)  # 創建覆蓋表面/ Create overlay surface
        overlay.fill((0, 0, 0, 30))  # 填充半透明黑/ Fill with semi-transparent black
        self.window.blit(overlay, (0, 0))  # 畫出覆蓋/ Blit the overlay
        
        self.handle_game_events()  # 處理遊戲事件/ Handle game events
        self.update_game_state()  # 更新遊戲狀態/ Update game state
        self.check_game_conditions()  # 檢查遊戲條件/ Check game conditions
        
        self.draw_game_elements()  # 畫出所有遊戲元素/ Draw game elements
        pygame.display.update()  # 更新螢幕/ Update display
        self.clock.tick(60)  # 控制更新速率/ Control update rate

    def handle_game_events(self):  # 定義處理遊戲事件的方法/ Define method to handle game events
        keys = pygame.key.get_pressed()  # 獲取鍵盤按鍵狀態/ Get keyboard state
        
        if self.my_tank.live:  # 如果玩家坦克存活/ If player tank is alive
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:  # 如果按下左箭頭或 A/ If left arrow or A key is pressed
                self.my_tank.direction = 'L'  # 設定方向為左/ Set direction to left
                self.my_tank.stop = False  # 玩家坦克開始移動/ Player tank starts moving
            elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:  # 如果按下右箭頭或 D/ If right arrow or D key is pressed
                self.my_tank.direction = 'R'  # 設定方向為右/ Set direction to right
                self.my_tank.stop = False  # 玩家坦克開始移動/ Player tank starts moving
            elif keys[pygame.K_UP] or keys[pygame.K_w]:  # 如果按下上箭頭或 W/ If up arrow or W key is pressed
                self.my_tank.direction = 'U'  # 設定方向為上/ Set direction to up
                self.my_tank.stop = False  # 玩家坦克開始移動/ Player tank starts moving
            elif keys[pygame.K_DOWN] or keys[pygame.K_s]:  # 如果按下下箭頭或 S/ If down arrow or S key is pressed
                self.my_tank.direction = 'D'  # 設定方向為下/ Set direction to down
                self.my_tank.stop = False  # 玩家坦克開始移動/ Player tank starts moving
            else:  # 否則/ Otherwise
                self.my_tank.stop = True  # 停止移動/ Stop movement

        for event in pygame.event.get():  # 取得所有事件/ Get all events
            if event.type == pygame.QUIT:  # 如果事件為退出/ If event is quit
                self.endGame()  # 結束遊戲/ End the game
            if event.type == pygame.KEYDOWN:  # 如果鍵盤按下/ If key is pressed down
                # 修改此處: 每次按下 space 鍵都會發射子彈，不限制子彈數量  # 修改此處: 每次按下空白鍵都發射子彈/ Modification: Fire a bullet every time space is pressed, without bullet limit
                if event.key == pygame.K_SPACE and self.my_tank.live:  # 如果按下空白鍵且玩家坦克存活/ If space is pressed and player tank is alive
                    self.myBulletList.append(Bullet(self.my_tank, self))  # 添加玩家子彈/ Append a new player bullet
                    Music('img/fire.wav').play()  # 播放開火音效/ Play fire sound

    def update_game_state(self):  # 定義更新遊戲狀態的方法/ Define method to update game state
        # Update player tank  # 更新玩家坦克/ Update player tank
        if self.my_tank.live and not self.my_tank.stop:  # 如果玩家坦克存活且正在移動/ If player tank is alive and moving
            self.my_tank.move()  # 移動玩家坦克/ Move player tank
            self.my_tank.hitWall()  # 檢查玩家與牆壁碰撞/ Check player collision with walls
            self.my_tank.myTank_hit_enemyTank()  # 檢查玩家與敵人坦克碰撞/ Check collision between player tank and enemy tanks
        
        # Update enemy tanks  # 更新敵人坦克/ Update enemy tanks
        for tank in self.enemyTankList[:]:  # 迭代所有敵人坦克/ Iterate over all enemy tanks
            if tank.live:  # 如果敵人坦克存活/ If enemy tank is alive
                tank.randMove()  # 隨機移動敵人坦克/ Move enemy tank randomly
                tank.hitWall()  # 檢查敵人坦克與牆壁碰撞/ Check enemy tank collision with walls
                bullet = tank.shot()  # 敌人坦克射擊/ Enemy tank shoots
                if bullet:  # 如果產生子彈/ If a bullet is created
                    self.enemyBulletList.append(bullet)  # 添加子彈到敵人子彈列表/ Append bullet to enemy bullet list
                if self.my_tank.live:  # 如果玩家坦克存活/ If player tank is alive
                    tank.enemyTank_hit_myTank()  # 檢查敵人坦克與玩家坦克碰撞/ Check collision between enemy tank and player tank
        
        self.enemyTankList = [tank for tank in self.enemyTankList if tank.live]  # 過濾掉已死亡的敵人坦克/ Filter out dead enemy tanks

        # Update bullets  # 更新子彈/ Update bullets
        for bullet in self.myBulletList[:]:  # 迭代所有玩家子彈/ Iterate over all player bullets
            bullet.move()  # 移動子彈/ Move bullet
            bullet.myBullet_hit_enemyTank()  # 檢查玩家子彈與敵人坦克碰撞/ Check collision between player bullet and enemy tank
            bullet.hitWall()  # 檢查子彈與牆壁碰撞/ Check bullet collision with walls
            if not bullet.live:  # 如果子彈不再存活/ If bullet is no longer alive
                self.myBulletList.remove(bullet)  # 從列表中移除子彈/ Remove bullet from list

        for bullet in self.enemyBulletList[:]:  # 迭代所有敵人子彈/ Iterate over all enemy bullets
            bullet.move()  # 移動子彈/ Move bullet
            bullet.enemyBullet_hit_myTank()  # 檢查敵人子彈與玩家坦克碰撞/ Check collision between enemy bullet and player tank
            bullet.hitWall()  # 檢查子彈與牆壁碰撞/ Check bullet collision with walls
            if not bullet.live:  # 如果子彈不再存活/ If bullet is no longer alive
                self.enemyBulletList.remove(bullet)  # 從列表中移除子彈/ Remove bullet from list

        # Update explosions  # 更新爆炸效果/ Update explosions
        for exp in self.explodeList[:]:  # 迭代所有爆炸效果/ Iterate over all explosions
            if not exp.live:  # 如果爆炸效果結束/ If explosion is finished
                self.explodeList.remove(exp)  # 從列表中移除爆炸/ Remove explosion from list

    def draw_game_elements(self):  # 定義畫出遊戲元素的方法/ Define method to draw game elements
        # Draw UI  # 畫出使用者介面/ Draw UI
        self.window.blit(self.get_text_surface(f"Enemies: {len(self.enemyTankList)}"), (10, 10))  # 畫出敵人數量/ Display number of enemies
        self.window.blit(self.get_text_surface(f"Score: {self.score}"), (10, 40))  # 畫出分數/ Display score

        # Draw walls  # 畫出牆壁/ Draw walls
        for wall in self.WallList:  # 迭代所有牆壁/ Iterate over all walls
            if wall.live:  # 如果牆壁存在/ If wall is active
                wall.displayWall()  # 顯示牆壁/ Display wall

        # Draw player tank  # 畫出玩家坦克/ Draw player tank
        if self.my_tank.live:  # 如果玩家坦克存活/ If player tank is alive
            self.my_tank.displayTank()  # 顯示玩家坦克/ Display player tank

        # Draw enemy tanks  # 畫出敵人坦克/ Draw enemy tanks
        for tank in self.enemyTankList:  # 迭代所有敵人坦克/ Iterate over all enemy tanks
            if tank.live:  # 如果敵人坦克存活/ If enemy tank is alive
                tank.displayTank()  # 顯示敵人坦克/ Display enemy tank

        # Draw bullets  # 畫出子彈/ Draw bullets
        for bullet in self.myBulletList + self.enemyBulletList:  # 迭代所有子彈/ Iterate over all bullets
            if bullet.live:  # 如果子彈存活/ If bullet is alive
                bullet.displayBullet()  # 顯示子彈/ Display bullet

        # Draw explosions  # 畫出爆炸效果/ Draw explosions
        for exp in self.explodeList:  # 迭代所有爆炸/ Iterate over all explosions
            exp.displayExplode()  # 顯示爆炸/ Display explosion

    def get_text_surface(self, text):  # 定義取得文字表面的方法/ Define method to get text surface
        font = Button.get_font(16)  # 獲取字體/ Get the font
        return font.render(text, True, TEXT_COLOR)  # 渲染文字並返回/ Render and return the text surface

    def check_game_conditions(self):  # 定義檢查遊戲條件的方法/ Define method to check game conditions
        if not self.my_tank.live:  # 如果玩家坦克死亡/ If player tank is dead
            self.game_state = GAME_OVER  # 設定遊戲狀態為結束/ Set game state to GAME_OVER
            self.result_text = "Game Over!"  # 設定結果文字/ Set result text
        elif len(self.enemyTankList) == 0:  # 如果沒有敵人坦克/ If no enemy tanks remain
            self.game_state = VICTORY  # 設定遊戲狀態為勝利/ Set game state to VICTORY
            self.result_text = "Victory!"  # 設定結果文字/ Set result text

    def endGame(self):  # 定義結束遊戲的方法/ Define method to end the game
        pygame.quit()  # 退出 pygame/ Quit pygame
        exit()  # 結束程式/ Exit the program

class Tank(BaseItem):  # 定義 Tank 類別，繼承自 BaseItem/ Define Tank class inheriting from BaseItem
    def __init__(self, left, top, game):  # 初始化 Tank/ Initialize Tank
        self.game = game  # 儲存遊戲實例/ Store the game instance
        self.images = {  # 定義坦克圖片/ Define tank images
            'U': load_image('img/p1tankU.gif'),  # 上方圖片/ Image facing up
            'D': load_image('img/p1tankD.gif'),  # 下方圖片/ Image facing down
            'L': load_image('img/p1tankL.gif'),  # 左側圖片/ Image facing left
            'R': load_image('img/p1tankR.gif'),  # 右側圖片/ Image facing right
        }
        self.direction = 'U'  # 初始化方向為上/ Initialize direction as up
        self.image = self.images[self.direction]  # 設定目前圖片/ Set current image
        self.rect = self.image.get_rect(center=(left, top))  # 定位坦克位置/ Position the tank
        self.speed = 5  # 設定速度/ Set speed
        self.stop = True  # 初始停止狀態/ Initial stopped state
        self.live = True  # 坦克存活/ Tank is alive
        self.old_pos = self.rect.topleft  # 儲存舊位置/ Store old position

    def displayTank(self):  # 定義顯示坦克的方法/ Define method to display the tank
        self.image = self.images[self.direction]  # 更新圖片/ Update image
        self.game.window.blit(self.image, self.rect)  # 畫出坦克/ Draw the tank

    def move(self):  # 定義移動方法/ Define move method
        self.old_pos = self.rect.topleft  # 保存目前位置/ Save current position
        if self.direction == 'L':  # 如果方向為左/ If direction is left
            self.rect.left = max(0, self.rect.left - self.speed)  # 向左移動且不超出螢幕/ Move left without leaving screen
        elif self.direction == 'R':  # 如果方向為右/ If direction is right
            self.rect.right = min(SCREEN_WIDTH, self.rect.right + self.speed)  # 向右移動且不超出螢幕/ Move right without leaving screen
        elif self.direction == 'U':  # 如果方向為上/ If direction is up
            self.rect.top = max(0, self.rect.top - self.speed)  # 向上移動且不超出螢幕/ Move up without leaving screen
        elif self.direction == 'D':  # 如果方向為下/ If direction is down
            self.rect.bottom = min(SCREEN_HEIGHT, self.rect.bottom + self.speed)  # 向下移動且不超出螢幕/ Move down without leaving screen

    def stay(self):  # 定義停止移動的方法/ Define method to stay in place
        self.rect.topleft = self.old_pos  # 回到原先位置/ Return to old position

    def hitWall(self):  # 定義碰撞牆壁檢查的方法/ Define method to check wall collisions
        for wall in self.game.WallList:  # 迭代所有牆壁/ Iterate through all walls
            if wall.live and self.rect.colliderect(wall.rect):  # 如果碰到牆壁/ If colliding with a wall
                self.stay()  # 回到原位/ Stay in place

class MyTank(Tank):  # 定義玩家坦克類別，繼承自 Tank/ Define MyTank class inheriting from Tank
    def __init__(self, left, top, game):  # 初始化玩家坦克/ Initialize player tank
        super().__init__(left, top, game)  # 呼叫父類別初始化/ Call superclass initializer
        self.speed = 5  # 設定速度/ Set speed

    def myTank_hit_enemyTank(self):  # 定義檢查與敵人坦克碰撞的方法/ Define method to check collision with enemy tanks
        for tank in self.game.enemyTankList:  # 迭代所有敵人坦克/ Iterate over all enemy tanks
            if tank.live and self.rect.colliderect(tank.rect):  # 如果碰撞發生/ If collision occurs
                self.stay()  # 保持原位/ Stay in place

class EnemyTank(Tank):  # 定義敵人坦克類別，繼承自 Tank/ Define EnemyTank class inheriting from Tank
    def __init__(self, left, top, speed, game):  # 初始化敵人坦克/ Initialize enemy tank
        super().__init__(left, top, game)  # 呼叫父類別初始化/ Call superclass initializer
        self.images = {  # 定義敵人坦克圖片/ Define enemy tank images
            'U': load_image('img/enemy1U.gif'),  # 上方圖片/ Image facing up
            'D': load_image('img/enemy1D.gif'),  # 下方圖片/ Image facing down
            'L': load_image('img/enemy1L.gif'),  # 左側圖片/ Image facing left
            'R': load_image('img/enemy1R.gif'),  # 右側圖片/ Image facing right
        }
        self.direction = random.choice(['U', 'D', 'L', 'R'])  # 隨機選擇初始方向/ Randomly choose initial direction
        self.speed = speed  # 設定移動速度/ Set moving speed
        self.step = 50  # 設定移動步數/ Set movement steps

    def randMove(self):  # 定義隨機移動的方法/ Define method for random movement
        if self.step <= 0:  # 如果步數耗盡/ If steps are exhausted
            self.direction = random.choice(['U', 'D', 'L', 'R'])  # 隨機改變方向/ Randomly change direction
            self.step = 50  # 重置步數/ Reset steps
        else:  # 否則/ Otherwise
            self.move()  # 移動坦克/ Move the tank
            self.step -= 1  # 步數減一/ Decrement steps

    def enemyTank_hit_myTank(self):  # 定義檢查敵人與玩家坦克碰撞的方法/ Define method to check collision with player tank
        if self.game.my_tank.live and self.rect.colliderect(self.game.my_tank.rect):  # 如果碰撞發生/ If collision occurs
            self.stay()  # 停止移動/ Stay in place

    def shot(self):  # 定義射擊的方法/ Define shooting method
        return Bullet(self, self.game) if random.randint(1, 100) < 5 else None  # 以 5% 機率射擊/ Shoot with 5% probability

class Bullet:  # 定義子彈類別/ Define Bullet class
    def __init__(self, tank, game):  # 初始化子彈/ Initialize bullet
        self.game = game  # 儲存遊戲實例/ Store game instance
        self.image = load_image('img/enemymissile.gif')  # 載入子彈圖片/ Load bullet image
        self.direction = tank.direction  # 繼承坦克的方向/ Inherit tank's direction
        self.rect = self.image.get_rect()  # 定義子彈矩形/ Define bullet rectangle
        self.speed = 7  # 設定子彈速度/ Set bullet speed
        self.live = True  # 子彈狀態/ Bullet is alive

        if self.direction == 'U':  # 如果方向為上/ If direction is up
            self.rect.midbottom = tank.rect.midtop  # 定位子彈起始位置/ Position bullet at tank's top
        elif self.direction == 'D':  # 如果方向為下/ If direction is down
            self.rect.midtop = tank.rect.midbottom  # 定位子彈起始位置/ Position bullet at tank's bottom
        elif self.direction == 'L':  # 如果方向為左/ If direction is left
            self.rect.midright = tank.rect.midleft  # 定位子彈起始位置/ Position bullet at tank's left
        elif self.direction == 'R':  # 如果方向為右/ If direction is right
            self.rect.midleft = tank.rect.midright  # 定位子彈起始位置/ Position bullet at tank's right

    def move(self):  # 定義子彈移動的方法/ Define bullet move method
        if not self.live:  # 如果子彈不再存活/ If bullet is not alive
            return  # 結束函式/ Exit function

        move_dist = {  # 定義不同方向的移動距離/ Define movement distances for each direction
            'U': (0, -self.speed),  # 上移/ Move up
            'D': (0, self.speed),  # 下移/ Move down
            'L': (-self.speed, 0),  # 左移/ Move left
            'R': (self.speed, 0)  # 右移/ Move right
        }[self.direction]
        self.rect.move_ip(move_dist)  # 移動子彈/ Move the bullet in place
        if not (0 <= self.rect.x <= SCREEN_WIDTH and 0 <= self.rect.y <= SCREEN_HEIGHT):  # 如果子彈離開螢幕/ If bullet leaves the screen
            self.live = False  # 設定子彈為不存活/ Mark bullet as not alive

    def displayBullet(self):  # 定義顯示子彈的方法/ Define method to display bullet
        if self.live:  # 如果子彈存活/ If bullet is alive
            self.game.window.blit(self.image, self.rect)  # 畫出子彈/ Draw the bullet

    def hitWall(self):  # 定義子彈與牆壁碰撞檢查/ Define bullet collision with walls
        for wall in self.game.WallList:  # 迭代所有牆壁/ Iterate over all walls
            if wall.live and self.rect.colliderect(wall.rect):  # 如果與牆壁碰撞/ If colliding with a wall
                self.live = False  # 子彈消失/ Bullet dies
                wall.hp -= 1  # 牆壁血量減少/ Decrease wall HP
                if wall.hp <= 0:  # 如果牆壁血量歸零/ If wall HP is zero
                    wall.live = False  # 牆壁被破壞/ Wall is destroyed

    def myBullet_hit_enemyTank(self):  # 定義玩家子彈檢查敵人坦克碰撞/ Define player bullet collision with enemy tanks
        if not self.live:  # 如果子彈不存活/ If bullet is not alive
            return  # 結束函式/ Exit function

        for tank in self.game.enemyTankList[:]:  # 迭代所有敵人坦克/ Iterate over all enemy tanks
            if tank.live and self.rect.colliderect(tank.rect):  # 如果碰撞發生/ If collision occurs
                self.live = False  # 子彈消失/ Bullet dies
                tank.live = False  # 敵人坦克被摧毀/ Enemy tank is destroyed
                self.game.score += 1  # 分數增加/ Increase score
                self.game.explodeList.append(Explode(tank, self.game))  # 添加爆炸效果/ Append explosion effect

    def enemyBullet_hit_myTank(self):  # 定義敵人子彈檢查玩家坦克碰撞/ Define enemy bullet collision with player tank
        if self.live and self.game.my_tank.live and self.rect.colliderect(self.game.my_tank.rect):  # 如果碰撞發生/ If collision occurs
            self.live = False  # 子彈消失/ Bullet dies
            self.game.my_tank.live = False  # 玩家坦克被摧毀/ Player tank is destroyed
            self.game.explodeList.append(Explode(self.game.my_tank, self.game))  # 添加爆炸效果/ Append explosion effect

class Wall:  # 定義牆壁類別/ Define Wall class
    def __init__(self, left, top, game):  # 初始化牆壁/ Initialize wall
        self.game = game  # 儲存遊戲實例/ Store game instance
        self.image = load_image('img/steels.gif')  # 載入牆壁圖片/ Load wall image
        self.rect = self.image.get_rect(center=(left, top))  # 設定牆壁位置/ Set wall position
        self.live = True  # 牆壁存在/ Wall is active
        self.hp = 3  # 設定牆壁血量/ Set wall HP

    def displayWall(self):  # 定義顯示牆壁的方法/ Define method to display wall
        if self.live:  # 如果牆壁存在/ If wall is active
            self.game.window.blit(self.image, self.rect)  # 畫出牆壁/ Draw the wall
            hp_width = self.rect.width * (self.hp / 3)  # 根據血量計算血條寬度/ Calculate HP bar width based on HP
            pygame.draw.rect(self.game.window, (0, 255, 0),  # 畫出血條/ Draw the HP bar
                (self.rect.left, self.rect.top - 5, hp_width, 3))  # 血條位置與尺寸/ HP bar position and size

class Explode:  # 定義爆炸效果類別/ Define Explode class
    def __init__(self, target, game):  # 初始化爆炸效果/ Initialize explosion effect
        self.game = game  # 儲存遊戲實例/ Store game instance
        self.images = [load_image(f'img/blast{i}.gif') for i in range(5)]  # 載入爆炸圖片序列/ Load sequence of explosion images
        self.image_index = 0  # 初始化圖片索引/ Initialize image index
        self.rect = target.rect.copy()  # 取得目標位置/ Get target's position
        self.live = True  # 爆炸效果存活/ Explosion is active

    def displayExplode(self):  # 定義顯示爆炸效果的方法/ Define method to display explosion
        if self.image_index < len(self.images):  # 如果還有爆炸圖片/ If there are explosion images remaining
            self.game.window.blit(self.images[self.image_index], self.rect)  # 畫出當前爆炸圖片/ Draw the current explosion image
            self.image_index += 1  # 切換到下一張圖片/ Move to the next image
        else:  # 否則/ Otherwise
            self.live = False  # 爆炸結束/ Explosion is finished

class Music:  # 定義音樂類別/ Define Music class
    def __init__(self, filename):  # 初始化音樂/ Initialize music
        try:  # 嘗試以下操作/ Try the following
            self.sound = pygame.mixer.Sound(filename)  # 載入音效檔案/ Load sound file
        except:  # 如果失敗/ In case of error
            self.sound = None  # 設定為 None/ Set sound to None

    def play(self):  # 定義播放音效的方法/ Define method to play sound
        if self.sound:  # 如果音效存在/ If sound exists
            self.sound.play()  # 播放音效/ Play the sound

if __name__ == '__main__':  # 如果直接執行此模組/ If running this module directly
    game = MainGame()  # 創建 MainGame 實例/ Create MainGame instance
    game.startGame()  # 開始遊戲/ Start the game
